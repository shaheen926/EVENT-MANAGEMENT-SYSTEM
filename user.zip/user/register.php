<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "event_managements";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("<p class='error'>Connection failed: " . $conn->connect_error . "</p>");
}

// Ensure event_id is passed in the URL
if (!isset($_GET['event_id'])) {
    die("<p class='error'>No event selected. Please go back and select an event.</p>");
}

$event_id = $_GET['event_id'];

// Fetch event details using event_id
$stmt = $conn->prepare("SELECT event_name, registration_fee, payment_qr_code FROM events WHERE event_id = ?");
$stmt->bind_param("i", $event_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("<p class='error'>Invalid event selected. Please go back and select a valid event.</p>");
}

$event = $result->fetch_assoc();
$event_name = $event['event_name'];
$registration_fee = $event['registration_fee'];
$qr_code = $event['payment_qr_code'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $usn = $_POST['usn'];
    $semester = $_POST['semester'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $branch = $_POST['branch'];
    $participation_type = $_POST['participation_type'];
    $group_size = isset($_POST['group_size']) ? $_POST['group_size'] : 1;
    $utr_number = $_POST['utr_number'];

    // Check if the user has already registered for this event
    $sql_check = "SELECT * FROM registrations WHERE usn = ? AND event_id = ?";
    $stmt_check = $conn->prepare($sql_check);
    $stmt_check->bind_param("si", $usn, $event_id);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();

    if ($result_check->num_rows > 0) {
        die("<p class='error'>You have already registered for this event. Please check your registration details.</p>");
    }

    // Insert registration into the database
    $sql = "INSERT INTO registrations (event_id, name, usn, semester, email, gender, event_name, branch, participation_type, group_size, registration_fee, payment_qr_code, utr_number)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "ississsssisss",
        $event_id,
        $name,
        $usn,
        $semester,
        $email,
        $gender,
        $event_name,
        $branch,
        $participation_type,
        $group_size,
        $registration_fee,
        $qr_code,
        $utr_number
    );

    if ($stmt->execute()) {
        // Get the inserted registration_id
        $registration_id = $stmt->insert_id;

        // Handle group member details if group participation
        if ($participation_type === 'Group') {
            for ($i = 1; $i <= $group_size; $i++) {
                $member_name = $_POST["member_name_$i"];
                $member_usn = $_POST["member_usn_$i"];

                // Insert each group member into the group_members table with the registration_id
                $sql_group = "INSERT INTO group_members (registration_id, member_name, member_usn) 
                              VALUES (?, ?, ?)";
                $stmt_group = $conn->prepare($sql_group);
                $stmt_group->bind_param("iss", $registration_id, $member_name, $member_usn);
                $stmt_group->execute();
            }
        }

        echo "<p class='success'>Registration successful for event: <b>$event_name</b>. Please wait for admin verification.</p>";
    } else {
        echo "<p class='error'>Error: " . $conn->error . "</p>";
    }
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        form {
            background: #fff;
            padding: 20px 30px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            width: 100%;
        }

        form h2 {
            margin-bottom: 20px;
            font-size: 24px;
            color: #333;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #555;
        }

        input[type="text"],
        input[type="number"],
        input[type="email"],
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }

        input[type="radio"] {
            margin-right: 5px;
        }

        .gender-container {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }

        .gender-container label {
            margin-right: 15px;
        }

        button {
            background: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            font-size: 16px;
        }

        button:hover {
            background: #0056b3;
        }

        .qr-container {
            margin-top: 20px;
            text-align: center;
        }

        .qr-container h3 {
            margin-bottom: 10px;
            font-size: 18px;
            color: #333;
        }

        .qr-container img {
            max-width: 200px;
            width: 100%;
            height: auto;
        }

        .success {
            background: #d4edda;
            color: #155724;
            padding: 10px;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            padding: 10px;
            border: 1px solid #f5c6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }
    </style>
    <script>
        function updateGroupMembers() {
            const participationType = document.getElementById('participation_type').value;
            const groupSizeContainer = document.getElementById('group_size_container');
            const groupMembersContainer = document.getElementById('group_members');

            if (participationType === 'Group') {
                groupSizeContainer.style.display = 'block';
            } else {
                groupSizeContainer.style.display = 'none';
                groupMembersContainer.innerHTML = '';
                return;
            }

            const groupSize = document.getElementById('group_size').value;
            groupMembersContainer.innerHTML = '';

            for (let i = 1; i <= groupSize; i++) {
                groupMembersContainer.innerHTML += `
                    <label for="member_name_${i}">Member ${i} Name</label>
                    <input type="text" id="member_name_${i}" name="member_name_${i}" placeholder="Enter Member ${i}'s Name" required>

                    <label for="member_usn_${i}">Member ${i} USN</label>
                    <input type="text" id="member_usn_${i}" name="member_usn_${i}" placeholder="Enter Member ${i}'s USN" required>`;
            }
        }
    </script>
</head>
<body>
    <form method="post">
        <h2>Register for <?= htmlspecialchars($event_name) ?></h2>

        <label for="name">Name</label>
        <input type="text" id="name" name="name" placeholder="Enter your full name" required>

        <label for="usn">USN</label>
        <input type="text" id="usn" name="usn" placeholder="Example: 2BA22IS087" required>

        <label for="semester">Semester</label>
        <input type="number" id="semester" name="semester" min="1" max="8" placeholder="Enter your semester" required>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" placeholder="Enter your email" required>

        <div class="gender-container">
            <label>Gender</label>
            <label><input type="radio" name="gender" value="Male" required> Male</label>
            <label><input type="radio" name="gender" value="Female" required> Female</label>
            <label><input type="radio" name="gender" value="Other" required> Other</label>
        </div>

        <label for="branch">Branch</label>
        <select id="branch" name="branch" required>
            <option value="">--Select Branch--</option>
            <option value="CSE">Computer Science and Engineering</option>
            <option value="ISE">Information Science and Engineering</option>
            <option value="ECE">Electronics and Communication Engineering</option>
        </select>

        <label for="participation_type">Participation Type</label>
        <select id="participation_type" name="participation_type" onchange="updateGroupMembers()" required>
            <option value="Individual">Individual</option>
            <option value="Group">Group</option>
        </select>

        <div id="group_size_container" style="display:none;">
            <label for="group_size">Group Size</label>
            <input type="number" id="group_size" name="group_size" min="1" max="10" value="2" onchange="updateGroupMembers()" required>
        </div>

        <div id="group_members"></div>

        <label for="utr_number">UTR Number</label>
        <input type="text" id="utr_number" name="utr_number" placeholder="Enter the UTR number of the payment" required>

        <div class="qr-container">
            <h3>Scan QR Code to Pay</h3>
            <img src="<?= htmlspecialchars($qr_code) ?>" alt="QR Code">
            <p>Registration Fee: ₹<?= htmlspecialchars($registration_fee) ?></p>
        </div>

        <button type="submit">Register</button>
    </form>
</body>
</html>
