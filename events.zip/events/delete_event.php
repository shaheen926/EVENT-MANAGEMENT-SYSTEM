<?php
$conn = new mysqli('localhost', 'root', '', 'event_managements');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $event_id = $_GET['event_id'];

    // Delete the event from the database
    $sql = "DELETE FROM events WHERE event_id = $event_id";

    if ($conn->query($sql) === TRUE) {
        echo "Event deleted successfully!";
        header('Location: manage_events.php');
    } else {
        echo "Error deleting event: " . $conn->error;
    }
}

$conn->close();
