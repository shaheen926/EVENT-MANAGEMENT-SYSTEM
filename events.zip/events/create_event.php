<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $department = $_POST['department'];
    $category = $_POST['category'];
    $event_name = $_POST['event_name'];
    $staff_coordinator = $_POST['staff_coordinator'];
    $start_date_time = $_POST['start_date_time'];
    $end_date_time = $_POST['end_date_time'];
    $location = $_POST['location'];
    $registration_closing_date_time = $_POST['registration_closing_date_time'];
    $registration_limit = $_POST['registration_limit'];
    $participation_type = $_POST['participation_type'];  // New field
    $min_group_size = isset($_POST['min_group_size']) ? $_POST['min_group_size'] : 1; // Default to 1
    $max_group_size = isset($_POST['max_group_size']) ? $_POST['max_group_size'] : 1; // Default to 1
    $description = $_POST['description'];
    $registration_fee = $_POST['registration_fee'];  // New field for registration fee

    // Handle the image upload for event image
    $image = "";
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $image_name = $_FILES['image']['name'];
        $image_tmp_name = $_FILES['image']['tmp_name'];
        $image_extension = pathinfo($image_name, PATHINFO_EXTENSION);
        $allowed_extensions = array("jpg", "jpeg", "png", "gif", "jfif");

        if (in_array(strtolower($image_extension), $allowed_extensions)) {
            $upload_path = "uploads/" . time() . "_" . $image_name;
            if (!is_dir('uploads')) {
                mkdir('uploads', 0777, true);
            }
            if (move_uploaded_file($image_tmp_name, $upload_path)) {
                $image = $upload_path;
            } else {
                echo "Error uploading image.";
            }
        } else {
            echo "Invalid image file type.";
        }
    }

    // Handle the image upload for payment QR code
    $payment_qr_code = "";
    if (isset($_FILES['payment_qr_code']) && $_FILES['payment_qr_code']['error'] == 0) {
        $qr_name = $_FILES['payment_qr_code']['name'];
        $qr_tmp_name = $_FILES['payment_qr_code']['tmp_name'];
        $qr_extension = pathinfo($qr_name, PATHINFO_EXTENSION);
        $allowed_qr_extensions = array("jpg", "jpeg", "png", "gif", "jfif");

        if (in_array(strtolower($qr_extension), $allowed_qr_extensions)) {
            $qr_upload_path = "uploads/qr_codes/" . time() . "_" . $qr_name;
            if (!is_dir('uploads/qr_codes')) {
                mkdir('uploads/qr_codes', 0777, true);
            }
            if (move_uploaded_file($qr_tmp_name, $qr_upload_path)) {
                $payment_qr_code = $qr_upload_path;
            } else {
                echo "Error uploading QR code.";
            }
        } else {
            echo "Invalid QR code file type.";
        }
    }

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'event_managements');
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Use prepared statements to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO events 
    (department, category, event_name, description, location, image, staff_coordinator, 
    start_date_time, end_date_time, registration_closing_date_time, registration_limit, 
    participation_type, min_group_size, max_group_size, registration_fee, payment_qr_code) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

$stmt->bind_param("ssssssssssiiisss", $department, $category, $event_name, $description, 
$location, $image, $staff_coordinator, $start_date_time, $end_date_time, 
$registration_closing_date_time, $registration_limit, $participation_type, $min_group_size, 
$max_group_size, $registration_fee, $payment_qr_code);

    // Execute the statement
    if ($stmt->execute()) {
        echo "New event created successfully.";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Event</title>
    <style>
        /* CSS styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 300vh;
        }

        .container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px 30px;
            max-width: 600px;
            width: 100%;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-size: 14px;
            margin-bottom: 8px;
            color: #555;
        }

        input, select, textarea {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-bottom: 15px;
            font-size: 14px;
        }

        button {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #218838;
        }

        .form-group {
            margin-bottom: 15px;
        }

        textarea {
            resize: vertical;
            min-height: 100px;
        }

        .back-button {
            display: block;
            margin: 10px 0;
            text-align: center;
            color: white;
            background-color: #007bff;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            text-decoration: none;
        }

        .back-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Create Event</h1>
        <form method="POST" action="create_event.php" enctype="multipart/form-data">
            <label>Department:</label>
            <select name="department" required>
                <option value="CSE">Computer Science & Engineering</option>
                <option value="ISE">Information Science & Engineering</option>
                <option value="ECE">Electronics & Communication Engineering</option>
                <option value="EEE">Electrical & Electronics Engineering</option>
                <option value="ME">Mechanical Engineering</option>
                <option value="CE">Civil Engineering</option>
                <option value="AI/ML">Artificial Intelligence & Machine Learning</option>
                <option value="Data Science">Data Science</option>
                <option value="Biotech">Biotechnology</option>
            </select>

            <label>Event Type:</label>
            <select name="category" required>
                <option value="Technical">Technical</option>
                <option value="Sports">Sports</option>
                <option value="Cultural">Cultural</option>
            </select>

            <label>Event Name:</label>
            <input type="text" name="event_name" required>

            <label>Staff Coordinator:</label>
            <input type="text" name="staff_coordinator" required>

            <label>Start Date and Time:</label>
            <input type="datetime-local" name="start_date_time" required>

            <label>End Date and Time:</label>
            <input type="datetime-local" name="end_date_time" required>

            <label>Location:</label>
            <input type="text" name="location" required>

            <label>Registration Closing Date:</label>
            <input type="datetime-local" name="registration_closing_date_time" required>

            <label>Registration Limit:</label>
            <input type="number" name="registration_limit" min="1" required>

            <label>Event Image:</label>
            <input type="file" name="image" required>

            <label>Event Description:</label>
            <textarea name="description" required></textarea>

            <label>Participation Type:</label>
            <select name="participation_type" required>
                <option value="Individual">Individual</option>
                <option value="Group">Group</option>
                <option value="Both">Both</option>
            </select>

            <label>Minimum Group Size (for Group events only):</label>
            <input type="number" name="min_group_size" min="1" value="1">

            <label>Maximum Group Size (for Group events only):</label>
            <input type="number" name="max_group_size" min="1" value="1">

            <label>Registration Fee:</label>
            <input type="number" name="registration_fee" min="0" step="0.01" required>

            <label>Payment QR Code (Optional):</label>
            <input type="file" name="payment_qr_code" accept="image/*">

            <button type="submit">Create Event</button>
        </form>
        <a href="admin_dashboard.php" class="back-button">Go Back</a>
    </div>
</body>
</html>
