<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "event_managements";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("<p class='error'>Connection failed: " . $conn->connect_error . "</p>");
}

// Ensure event_id is passed in the URL
if (!isset($_GET['event_id'])) {
    die("<p class='error'>No event selected. Please go back and select an event.</p>");
}

$event_id = $_GET['event_id'];

// Fetch event details (corrected query)
$stmt = $conn->prepare("SELECT event_name, start_date_time, event_location FROM events WHERE event_id = ?");
$stmt->bind_param("i", $event_id);
$stmt->execute();
$event_result = $stmt->get_result();
$event = $event_result->fetch_assoc();
$event_name = $event['event_name'];
$event_date = $event['start_date_time'];  // Using start_date_time
$event_location = $event['event_location'];

// Fetch registrations for the event
$stmt = $conn->prepare("SELECT r.name, r.usn, r.semester, r.email, r.registration_time, r.participation_type, r.group_size, r.payment_proof 
                        FROM registrations r WHERE r.event_id = ?");
$stmt->bind_param("i", $event_id);
$stmt->execute();
$registrations_result = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registered Students for <?= htmlspecialchars($event_name) ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }

        .container {
            width: 90%;
            margin: 0 auto;
            padding: 20px;
        }

        h1 {
            font-size: 28px;
            color: #333;
            text-align: center;
        }

        .event-info {
            text-align: center;
            margin-bottom: 20px;
        }

        .event-info p {
            font-size: 18px;
            margin: 5px 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        td {
            background-color: #fff;
        }

        .action-btn {
            background-color: #28a745;
            color: white;
            padding: 5px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .action-btn:hover {
            background-color: #218838;
        }

        .error {
            background-color: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Registered Students for <?= htmlspecialchars($event_name) ?></h1>
    
    <div class="event-info">
        <p><strong>Date:</strong> <?= htmlspecialchars($event_date) ?></p>
        <p><strong>Location:</strong> <?= htmlspecialchars($event_location) ?></p>
    </div>

    <?php if ($registrations_result->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>USN</th>
                    <th>Semester</th>
                    <th>Email</th>
                    <th>Registration Time</th>
                    <th>Participation Type</th>
                    <th>Group Size</th>
                    <th>Group Members</th>
                    <th>Payment Proof</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $registrations_result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['name']) ?></td>
                        <td><?= htmlspecialchars($row['usn']) ?></td>
                        <td><?= htmlspecialchars($row['semester']) ?></td>
                        <td><?= htmlspecialchars($row['email']) ?></td>
                        <td><?= htmlspecialchars($row['registration_time']) ?></td>
                        <td><?= htmlspecialchars($row['participation_type']) ?></td>
                        <td><?= htmlspecialchars($row['group_size']) ?></td>
                        <td>
                            <?php
                            if ($row['participation_type'] == 'Group') {
                                $group_sql = "SELECT member_name FROM group_members WHERE registration_id = ?";
                                $group_stmt = $conn->prepare($group_sql);
                                $group_stmt->bind_param("i", $row['registration_id']);
                                $group_stmt->execute();
                                $group_result = $group_stmt->get_result();
                                $group_members = [];
                                while ($group_member = $group_result->fetch_assoc()) {
                                    $group_members[] = $group_member['member_name'];
                                }
                                echo implode(", ", $group_members);
                            } else {
                                echo "Individual";
                            }
                            ?>
                        </td>
                        <td>
                            <?php
                            if ($row['payment_proof'] == NULL || $row['payment_proof'] == '') {
                                echo "No proof uploaded";
                            } else {
                                echo "Proof uploaded";
                            }
                            ?>
                        </td>
                        <td>
                            <button class="action-btn">Confirm</button>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="error">No students have registered for this event yet.</p>
    <?php endif; ?>

    <p style="text-align: center;">
        <a href="dashboard.php"><button class="action-btn">Back to Dashboard</button></a>
    </p>
</div>

</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
