<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "event_managements";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get form data
    $event_id = $_POST['event_id'];
    $student_name = $_POST['student_name'];
    $student_email = $_POST['student_email'];
    $name = $_POST['name'] ?? $student_name;
    $usn = $_POST['usn'] ?? '';
    $semester = $_POST['semester'] ?? '';
    $gender = $_POST['gender'] ?? '';
    $branch = $_POST['branch'] ?? '';

    // Debugging - Output the values received from the form
    echo "Event ID: " . htmlspecialchars($event_id) . "<br>";
    echo "Student Name: " . htmlspecialchars($student_name) . "<br>";
    echo "Student Email: " . htmlspecialchars($student_email) . "<br>";

    // Validate event ID and retrieve event name
    $event_query = "SELECT event_name FROM events WHERE event_id = ?";
    $stmt = $conn->prepare($event_query);
    $stmt->bind_param("i", $event_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the event ID exists in the events table
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $event_name = $row['event_name'];
        echo "Event Name: " . htmlspecialchars($event_name) . "<br>"; // Debugging line

        // Insert registration details into the database
        $insert_query = "INSERT INTO registrations (event_id, name, usn, semester, email, gender, branch, event_name, registration_time)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())";
        $stmt = $conn->prepare($insert_query);
        $stmt->bind_param("ississss", $event_id, $name, $usn, $semester, $student_email, $gender, $branch, $event_name);

        if ($stmt->execute()) {
            // Send confirmation email
            $subject = "Event Registration Confirmation";
            $message = "Dear $name,\n\nYou have successfully registered for the event: $event_name.\n\nHere are your registration details:\n\nName: $name\nEvent: $event_name\n\nThank you for registering!\n\nBest regards,\nEvent Management Team";
            $headers = "From: no-reply@example.com";

            if (mail($student_email, $subject, $message, $headers)) {
                echo "<p class='success'>Registration successful! A confirmation email has been sent to $student_email.</p>";
            } else {
                echo "<p class='error'>Error sending confirmation email.</p>";
            }
        } else {
            echo "<p class='error'>Error: " . $stmt->error . "</p>";
        }
    } else {
        echo "<p class='error'>Invalid event selected. Please try again.</p>";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: rgb(82, 100, 135);
        }

        .registration-container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .registration-container h1 {
            text-align: center;
            color: #003366;
            font-size: 28px;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-size: 18px;
            color: #003366;
            margin-bottom: 5px;
        }

        select, input[type="text"], input[type="email"], input[type="number"] {
            padding: 10px;
            margin-bottom: 15px;
            border: 2px solid #003366;
            border-radius: 5px;
            font-size: 16px;
            width: 100%;
            box-sizing: border-box;
        }

        button {
            background-color: #003366;
            color: white;
            padding: 10px;
            font-size: 18px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #ffcc00;
            color: #003366;
        }

        .error {
            color: red;
            font-size: 14px;
        }

        .success {
            color: green;
            font-size: 16px;
            margin-top: 15px;
        }
    </style>
</head>
<body>
    <div class="registration-container">
        <h1>Register for an Event</h1>
        <form method="POST" action="">
            <label for="event_id">Event ID:</label>
            <input type="number" id="event_id" name="event_id" required>

            <label for="student_name">Student Name:</label>
            <input type="text" id="student_name" name="student_name" placeholder="Enter your full name" required>

            <label for="student_email">Student Email:</label>
            <input type="email" id="student_email" name="student_email" placeholder="Enter your email ID" required>

            <label for="name">Full Name:</label>
            <input type="text" id="name" name="name" placeholder="Enter your full name">

            <label for="usn">USN:</label>
            <input type="text" id="usn" name="usn" placeholder="Example: 2BA22IS087">

            <label for="semester">Semester:</label>
            <input type="number" id="semester" name="semester" min="1" max="8" placeholder="Enter your semester">

            <label>Gender:</label>
            <div>
                <label><input type="radio" name="gender" value="Male"> Male</label>
                <label><input type="radio" name="gender" value="Female"> Female</label>
                <label><input type="radio" name="gender" value="Other"> Other</label>
            </div>

            <label for="branch">Branch:</label>
            <select id="branch" name="branch">
                <option value="">--Select Branch--</option>
                <option value="Computer Science and Engineering">Computer Science and Engineering</option>
                <option value="Information Science and Engineering">Information Science and Engineering</option>
                <option value="Artificial Intelligence and Machine Learning">Artificial Intelligence and Machine Learning</option>
                <option value="Electronics and Communication Engineering">Electronics and Communication Engineering</option>
                <option value="Mechanical Engineering">Mechanical Engineering</option>
                <option value="Civil Engineering">Civil Engineering</option>
                <option value="Electrical and Electronics Engineering">Electrical and Electronics Engineering</option>
            </select>

            <button type="submit">Register</button>
        </form>
    </div>
</body>
</html>
