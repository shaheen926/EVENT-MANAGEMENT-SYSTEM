<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'event_managements');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch feedback data from Google Sheets (CSV URL)
$csv_url = "https://docs.google.com/spreadsheets/d/e/2PACX-1vQ4vtokDcHkQ_6gcPCkaHQajg702hBQsbm5DbKsIu0KS-5yAC9nF0_QhWodYGMTmpbdti4pnP_ew_yd/pub?output=csv";
$csv_data = @file_get_contents($csv_url);

// Error handling for CSV fetching
if ($csv_data === false) {
    die("Error fetching feedback data.");
}

// Parse CSV data
$rows = array_map('str_getcsv', explode("\n", $csv_data));
$header = array_shift($rows); // Remove header

// Insert feedback into the database (if it doesn't already exist)
foreach ($rows as $row) {
    if (count($row) >= 6) {  // Ensure there are enough columns
        $event_name = $row[5];  // Event Name column
        $name = $row[1];        // Name column
        $usn = $row[2];         // USN column
        $rating = $row[3];      // Rating column
        $suggestions = $row[4]; // Suggestions column

        // Check if the feedback already exists
        $check_sql = "SELECT * FROM feedback WHERE name = ? AND usn = ? AND event_name = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("sss", $name, $usn, $event_name);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();

        if ($check_result->num_rows == 0) { // Insert only if no duplicate exists
            $insert_sql = "INSERT INTO feedback (event_name, name, usn, rating, suggestions) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($insert_sql);
            $stmt->bind_param("sssss", $event_name, $name, $usn, $rating, $suggestions);
            $stmt->execute();
        }
    }
}

// Pagination setup
$limit = 10;  // Number of records per page
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Fetch feedback data from the database, excluding deleted feedback
$feedback_sql = "SELECT * FROM feedback WHERE deleted_at IS NULL ORDER BY event_name, name LIMIT ?, ?";
$stmt = $conn->prepare($feedback_sql);
$stmt->bind_param("ii", $offset, $limit);
$stmt->execute();
$feedback_result = $stmt->get_result();

// Fetch total count of feedback for pagination
$total_sql = "SELECT COUNT(*) AS total FROM feedback WHERE deleted_at IS NULL";
$total_result = $conn->query($total_sql);
$total_row = $total_result->fetch_assoc();
$total_feedbacks = $total_row['total'];
$total_pages = ceil($total_feedbacks / $limit);

// Delete feedback (soft delete) logic
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $delete_sql = "UPDATE feedback SET deleted_at = NOW() WHERE id = ?";
    $delete_stmt = $conn->prepare($delete_sql);
    $delete_stmt->bind_param("i", $delete_id);
    $delete_stmt->execute();
    header("Location: view_feedback.php"); // Redirect after deletion
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Feedback</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f9; color: #333; }
        .container { max-width: 800px; margin: 0 auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); }
        h1 { text-align: center; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 10px; text-align: left; border: 1px solid #ddd; }
        th { background-color: #007BFF; color: white; }
        tr:nth-child(even) { background-color: #f2f2f2; }
        tr:hover { background-color: #d1ecf1; }
        .pagination { text-align: center; margin-top: 20px; }
        .pagination a { margin: 0 5px; padding: 5px 10px; background-color: #007BFF; color: white; text-decoration: none; border-radius: 5px; }
        .pagination a:hover { background-color: #0056b3; }
    </style>
</head>
<body>
<div class="container">
    <h1>All Feedback</h1>

    <?php if ($feedback_result->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Event Name</th>
                    <th>Name</th>
                    <th>USN</th>
                    <th>Rating</th>
                    <th>Suggestions</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $feedback_result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['event_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><?php echo htmlspecialchars($row['usn']); ?></td>
                        <td><?php echo htmlspecialchars($row['rating']); ?></td>
                        <td><?php echo htmlspecialchars($row['suggestions']); ?></td>
                        <td>
                            <a href="view_feedback.php?delete_id=<?php echo $row['id']; ?>" 
                               onclick="return confirm('Are you sure you want to delete this feedback?');" 
                               style="color: red;">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <!-- Pagination -->
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="view_feedback.php?page=<?php echo $page - 1; ?>">Previous</a>
            <?php endif; ?>
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <a href="view_feedback.php?page=<?php echo $i; ?>"><?php echo $i; ?></a>
            <?php endfor; ?>
            <?php if ($page < $total_pages): ?>
                <a href="view_feedback.php?page=<?php echo $page + 1; ?>">Next</a>
            <?php endif; ?>
        </div>

    <?php else: ?>
        <p>No feedback received yet.</p>
    <?php endif; ?>

</div>
</body>
</html>

<?php
// Close connection
$conn->close();
?>
