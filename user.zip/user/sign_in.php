<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In & Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(to bottom right, #6a11cb, #2575fc);
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background: rgba(255, 255, 255, 0.1);
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
            width: 300px;
            text-align: center;
        }

        h1 {
            font-size: 2rem;
            margin-bottom: 1rem;
        }

        label {
            display: block;
            margin: 1rem 0 0.5rem;
            text-align: left;
        }

        input {
            width: 100%;
            padding: 0.5rem;
            margin-bottom: 1rem;
            border: none;
            border-radius: 6px;
        }

        button {
            padding: 0.7rem;
            width: 100%;
            border: none;
            border-radius: 6px;
            background: #4CAF50;
            color: white;
            font-size: 1rem;
            cursor: pointer;
        }

        button:hover {
            background: #45a049;
        }

        .link {
            margin-top: 1rem;
            display: block;
            color: #00c9ff;
            cursor: pointer;
        }

        .error {
            color: red;
            font-size: 0.8rem;
        }
    </style>
</head>
<body>
    <div class="container" id="signInContainer">
        <h1>Sign In</h1>
        <form id="signInForm">
            <label for="email">Email ID:</label>
            <input type="email" id="email" placeholder="Enter your email" required>

            <label for="password">Password:</label>
            <input type="password" id="password" placeholder="Enter your password" required>

            <button type="button" onclick="verifyEmail()">Sign In</button>

            <span class="link" onclick="showForgotPassword()">Forgot Password?</span>
            <span class="link" onclick="showLoginPage()">Go to Login</span>
            <div id="signInError" class="error"></div>
        </form>
    </div>

    <div class="container" id="loginContainer" style="display:none;">
        <h1>Login</h1>
        <form id="loginForm">
            <label for="username">Username:</label>
            <input type="text" id="username" placeholder="Enter your username" required>

            <label for="loginPassword">Password:</label>
            <input type="password" id="loginPassword" placeholder="Enter your password" required>

            <button type="button" onclick="loginUser()">Login</button>

            <span class="link" onclick="showForgotPassword()">Forgot Password?</span>
            <span class="link" onclick="showSignInPage()">Back to Sign In</span>
            <div id="loginError" class="error"></div>
        </form>
    </div>

    <div class="container" id="forgotPasswordContainer" style="display:none;">
        <h1>Forgot Password</h1>
        <form id="forgotPasswordForm">
            <label for="resetEmail">Enter your email:</label>
            <input type="email" id="resetEmail" placeholder="Enter your email" required>

            <button type="button" onclick="resetPassword()">Reset Password</button>

            <span class="link" onclick="showSignInPage()">Back to Sign In</span>
        </form>
    </div>

    <script>
        const users = {}; // Store user data

        function verifyEmail() {
            const email = document.getElementById("email").value;
            const password = document.getElementById("password").value;
            const error = document.getElementById("signInError");

            if (!users[email]) {
                error.textContent = "Email not registered! Please sign up.";
            } else if (users[email].password !== password) {
                error.textContent = "Invalid email or password!";
            } else {
                alert("Email verified! Please create your username and password.");
                showLoginPage();
            }
        }

        function loginUser() {
            const username = document.getElementById("username").value;
            const loginPassword = document.getElementById("loginPassword").value;
            const error = document.getElementById("loginError");

            for (const email in users) {
                if (
                    users[email].username === username &&
                    users[email].password === loginPassword
                ) {
                    alert("Login successful!");
                    return;
                }
            }

            error.textContent = "Invalid username or password!";
        }

        function resetPassword() {
            const email = document.getElementById("resetEmail").value;

            if (!users[email]) {
                alert("Email not registered!");
            } else {
                const newPassword = prompt("Enter your new password:");
                users[email].password = newPassword;
                alert("Password reset successful!");
                showSignInPage();
            }
        }

        function showSignInPage() {
            document.getElementById("signInContainer").style.display = "block";
            document.getElementById("loginContainer").style.display = "none";
            document.getElementById("forgotPasswordContainer").style.display = "none";
        }

        function showLoginPage() {
            document.getElementById("signInContainer").style.display = "none";
            document.getElementById("loginContainer").style.display = "block";
            document.getElementById("forgotPasswordContainer").style.display = "none";
        }

        function showForgotPassword() {
            document.getElementById("signInContainer").style.display = "none";
            document.getElementById("loginContainer").style.display = "none";
            document.getElementById("forgotPasswordContainer").style.display = "block";
        }
    </script>
</body>
</html> 