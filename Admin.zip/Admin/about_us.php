<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f6f9;
            color: #333;
        }

        /* Header Styles */
        .header {
            text-align: center;
            background-color: #007bff;
            color: #fff;
            padding: 30px 20px;
        }

        .header h1 {
            font-size: 2.5rem;
            margin: 0;
        }

        .header h2 {
            font-size: 1.5rem;
            margin-top: 10px;
        }

        /* About Section Styles */
        .about {
            max-width: 800px;
            margin: 40px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .about img {
            max-width: 200%;
            height: 100%;
            border-radius: 10px;
            margin-bottom: 10px;
        }

        .about p {
            font-size: 1.1rem;
            line-height: 1.6;
            margin: 20px 0;
            color: #555;
        }

        /* Contact Section Styles */
        .contact {
            text-align: center;
            padding: 20px;
            background-color: #007bff;
            color: #fff;
            margin-top: 40px;
        }

        .contact h2 {
            font-size: 1.8rem;
            margin-bottom: 10px;
        }

        .contact p {
            font-size: 1.2rem;
        }

        .contact a {
            color: #ffeb3b;
            text-decoration: none;
            font-weight: bold;
        }

        .contact a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <!-- Header Section -->
    <div class="header">
        <h1>Basaveshwar Engineering College (Autonomous)</h1>
        <h2>Where Excellence Meets Innovation</h2>
    </div>

    <!-- About Section -->
    <div class="about">
        <img src="images/1709387943.png" alt="Basaveshwar Engineering College" />
        <p>
            Welcome to Basaveshwar Engineering College (Autonomous), a prestigious institution located in Bagalkot, Karnataka. 
            Known for its excellence in academics, research, and student development, the college has consistently been at the forefront of engineering education in India.
        </p>
        <p>
            At BEC, we pride ourselves on fostering innovation, creativity, and collaboration to prepare our students for the challenges of the future.
        </p>
        <a href="index.php">
        <button class="back-button">Home</button>
    </div>
   

    <!-- Contact Section -->
    <div class="contact">
        <h2>Contact Us</h2>
        <p>Email: <a href="mailto:beceventsphere@gmail.com">beceventsphere@gmail.com</a></p>
    </div>

</body>
</html>
