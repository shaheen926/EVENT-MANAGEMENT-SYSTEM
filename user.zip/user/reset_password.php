<?php
session_start();

// Include PHPMailer for sending emails
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Autoload PHPMailer

// Database connection
$conn = new mysqli("localhost", "root", "", "event_managements");
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$message = ""; // To store messages

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Step 1: Send the verification code
    if (isset($_POST['send_code'])) {
        $email = trim($_POST['email']);
        $_SESSION['email_to_reset'] = $email; // Store email in session

        // Check if the email exists in the database
        $query = "SELECT * FROM users WHERE email = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Generate a random 4-digit verification code
            $verification_code = rand(1000, 9999);
            $_SESSION['verification_code'] = $verification_code; // Store code in session

            // Send email with the verification code
            $mail = new PHPMailer(true);

            try {
                // SMTP settings
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'shaheenthaned@gmail.com'; // Replace with your Gmail address
                $mail->Password = 'tsia ljwd tzyx gjkz'; // Replace with your Gmail App Password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                // Email content
                $mail->setFrom('shaheenthaned@gmail.com', 'Event Management');
                $mail->addAddress($email);
                $mail->isHTML(true);
                $mail->Subject = 'Password Reset Verification Code';
                $mail->Body = "
                    <p>Hello,</p>
                    <p>We received a request to reset your password. Please use the following verification code:</p>
                    <p><strong>$verification_code</strong></p>
                    <p>If you did not request this, please ignore this email.</p>
                    <p>Best regards,<br>Event Management Team</p>
                ";

                $mail->send();
                $message = "A verification code has been sent to your email.";
            } catch (Exception $e) {
                $message = "Verification email could not be sent. Mailer Error: " . $mail->ErrorInfo;
            }
        } else {
            $message = "Email not found. Please check the email address.";
        }
    }

    // Step 2: Verify the code
    if (isset($_POST['verify_code'])) {
        $entered_code = trim($_POST['code']);
        if (isset($_SESSION['verification_code']) && $entered_code == $_SESSION['verification_code']) {
            $_SESSION['is_verified'] = true; // Mark the code as verified
            $message = "Verification successful. Please enter a new password.";
        } else {
            $message = "Invalid verification code. Please try again.";
        }
    }

    // Resend the verification code
    if (isset($_POST['resend_code'])) {
        if (isset($_SESSION['email_to_reset'])) {
            $email = $_SESSION['email_to_reset']; // Retrieve the email from the session

            // Generate a new random 4-digit verification code
            $verification_code = rand(1000, 9999);
            $_SESSION['verification_code'] = $verification_code; // Store new code in session

            // Send the email again with the new verification code
            $mail = new PHPMailer(true);
            try {
                // SMTP settings
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'shaheenthaned@gmail.com'; // Replace with your Gmail address
                $mail->Password = 'tsia ljwd tzyx gjkz'; // Replace with your Gmail App Password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                // Email content
                $mail->setFrom('shaheenthaned@gmail.com', 'Event Management');
                $mail->addAddress($email);
                $mail->isHTML(true);
                $mail->Subject = 'Password Reset Verification Code';
                $mail->Body = "
                    <p>Hello,</p>
                    <p>We received a request to reset your password. Please use the following verification code:</p>
                    <p><strong>$verification_code</strong></p>
                    <p>If you did not request this, please ignore this email.</p>
                    <p>Best regards,<br>Event Management Team</p>
                ";

                $mail->send();
                $message = "A new verification code has been sent to your email.";
            } catch (Exception $e) {
                $message = "Verification email could not be sent. Mailer Error: " . $mail->ErrorInfo;
            }
        } else {
            $message = "Email not found. Please check the email address.";
        }
    }

    // Step 3: Reset the password
    if (isset($_POST['reset_password'])) {
        if (isset($_SESSION['is_verified']) && $_SESSION['is_verified'] === true) {
            $new_password = trim($_POST['new_password']);
            $confirm_password = trim($_POST['confirm_password']);

            // Password validation
            if ($new_password === $confirm_password && preg_match("/^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$/", $new_password)) {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

                // Update password in the database
                $email = $_SESSION['email_to_reset'];
                $update_query = "UPDATE users SET password = ? WHERE email = ?";
                $stmt = $conn->prepare($update_query);
                $stmt->bind_param("ss", $hashed_password, $email);

                if ($stmt->execute()) {
                    $message = "Password reset successful. You can now log in.";
                    // Clear session data
                    session_unset();
                    session_destroy();
                    // Display Login Now button
                    echo "<div class='message'>
                            <p>Password reset successful. You can now log in.</p>
                            <a href='login.php' class='btn-login'>Login Now</a>
                          </div>";
                } else {
                    $message = "Error updating the password. Please try again.";
                }
            } else {
                $message = "Passwords do not match or do not meet the required format. Password must be at least 6 characters long, include one uppercase letter, one number, and one special character.";
            }
        } else {
            $message = "Please verify your email first.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }
        h2 {
            text-align: center;
        }
        .container {
            max-width: 500px;
            margin: auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        input, button {
            display: block;
            width: 100%;
            margin: 10px 0;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .message {
            background-color: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 4px;
            text-align: center;
        }
        .btn-login {
            display: inline-block;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            text-align: center;
            text-decoration: none;
            font-size: 16px;
            border-radius: 4px;
            margin-top: 10px;
        }
        .btn-login:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h2>Reset Password</h2>
    <div class="container">
        <?php if ($message): ?>
            <div class="message"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <?php if (!isset($_SESSION['email_to_reset'])): ?>
            <!-- Step 1: Enter email -->
            <form method="POST">
                <label for="email">Enter your email:</label>
                <input type="email" name="email" required>
                <button type="submit" name="send_code">Send Verification Code</button>
            </form>
        <?php elseif (!isset($_SESSION['is_verified'])): ?>
            <!-- Step 2: Verify code -->
            <form method="POST">
                <label for="code">Enter the verification code sent to your email:</label>
                <input type="text" name="code" required>
                <button type="submit" name="verify_code">Verify Code</button>
            </form>
            <form method="POST">
                <button type="submit" name="resend_code">Resend Code</button>
            </form>
        <?php else: ?>
            <!-- Step 3: Reset password -->
            <form method="POST">
                <label for="new_password">New Password:</label>
                <input type="password" name="new_password" required>
                <label for="confirm_password">Confirm New Password:</label>
                <input type="password" name="confirm_password" required>
                <button type="submit" name="reset_password">Reset Password</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
