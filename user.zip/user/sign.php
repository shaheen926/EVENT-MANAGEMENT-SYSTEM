<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "event_managements");

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$message = ""; // To store success or error messages

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];

    // Validate email format
    if (filter_var($email, FILTER_VALIDATE_EMAIL) && strpos($email, '@gmail.com') !== false) {
        // Check if the email is already registered
        $query = "SELECT * FROM users WHERE email = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $message = "Email already registered. Please proceed to <a href='login.php'>login</a>.";
        } else {
            // Insert email into the database (DO NOT include `id` in the insert query)
            $query = "INSERT INTO users (email) VALUES (?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("s", $email);

            if ($stmt->execute()) {
                // Redirect to username and password creation page
                header("Location: create_account.php?email=" . urlencode($email));
                exit;
            } else {
                $message = "Error registering email. Please try again.";
            }
        }
    } else {
        $message = "Please enter a valid email in the format 'yourname@gmail.com'.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Registration</title>
    <style>
        /* General styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f4f8;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        /* Form container */
        .container {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            width: 100%;
            text-align: center;
        }

        /* Heading */
        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        h2 {
            margin-bottom: 20px;
            color: #007bff;
        }

        /* Form styles */
        label {
            font-size: 14px;
            color: #555;
            text-align: left;
            display: block;
            margin-bottom: 5px;
        }

        input[type="email"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
            outline: none;
            transition: border-color 0.3s;
        }

        input[type="email"]:focus {
            border-color: #007bff;
        }

        button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 14px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #0056b3;
        }

        /* Message styles */
        p {
            font-size: 14px;
            color: #333;
        }

        p a {
            color: #007bff;
            text-decoration: none;
            font-weight: bold;
        }

        p a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to Event Management System</h1>
        <h2>Email Registration</h2>
        <?php if ($message): ?>
            <p><?php echo $message; ?></p>
        <?php endif; ?>
        <form method="POST">
            <label for="email">Enter your Email:</label>
            <input type="email" name="email" required>
            <button type="submit">Submit</button>
            
        </form><br> <br>
        <a href="index.php">
            <button class="back-button">Go Back</button>
    </div>
</body>
</html>
