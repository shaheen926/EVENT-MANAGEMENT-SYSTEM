<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'event_managements');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all events from the database
$sql = "SELECT * FROM events";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Events</title>
    <style>
     * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body Styling */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #eef2f3;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 30px;
            color: #333;
        }

        /* Table Container */
        .table-container {
            width: 200%;
            max-width: 20000px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            overflow-x: auto;
            padding: 20px;
        }

        /* Heading */
        .table-container h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        /* Back Button Styling */
        .back-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 1rem;
            text-align: center;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-bottom: 20px;
        }

        .back-button:hover {
            background-color: #45a049;
        }

        /* Table Styling */
        table {
            width: 100%;
            border-collapse: collapse;
            text-align: center;
        }

        th, td {
            padding: 15px;
            border: 1px solid #ddd;
        }

        th {
            background-color: #007BFF;
            color: white;
            font-size: 1rem;
            text-transform: uppercase;
        }

        td {
            background-color: #f9f9f9;
            font-size: 0.95rem;
        }

        /* Row Hover Effect */
        tr:hover {
            background-color: #f1f1f1;
        }

        /* Image Styling */
        img {
            max-width: 100px;
            height: auto;
            border-radius: 5px;
            border: 1px solid #ddd;
        }

        /* Action Button Styling */
        .btn {
            padding: 8px 16px;
            margin: 5px;
            text-decoration: none;
            border-radius: 5px;
            font-size: 0.9rem;
            display: inline-block;
            text-align: center;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .btn-update {
            background-color: #007BFF;
            color: white;
        }

        .btn-update:hover {
            background-color: #0056b3;
        }

        .btn-delete {
            background-color: #FF4D4D;
            color: white;
        }

        .btn-delete:hover {
            background-color: #e60000;
        }

        .btn-view {
            background-color: #28a745;
            color: white;
        }

        .btn-view:hover {
            background-color: #1e7e34;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            table {
                font-size: 0.85rem;
            }

            th, td {
                padding: 10px;
            }
        }
    </style>
</head>
<body>

<div class="table-container">
    <h2>Manage Events</h2>
    <table>
        <tr>
            <th>Event Name</th>
            <th>Event Type</th>
            <th>Description</th>
            <th>Coordinator</th>
            <th>Start Time</th>
            <th>End Time</th>
            <th>Location</th>
            <th>Registration Fee</th>
            <th>Registration Closing Date</th>
            <th>Participation Type</th>
            <th>Min Group Size</th>
            <th>Max Group Size</th>
            <th>Actions</th>
        </tr>

        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo htmlspecialchars($row['event_name']); ?></td>
            <td><?php echo htmlspecialchars($row['category']); ?></td>
            <td><?php echo htmlspecialchars($row['description']); ?></td>
            <td><?php echo htmlspecialchars($row['staff_coordinator']); ?></td>
            <td><?php echo htmlspecialchars($row['start_date_time']); ?></td>
            <td><?php echo htmlspecialchars($row['end_date_time']); ?></td>
            <td><?php echo htmlspecialchars($row['location']); ?></td>
            <td><?php echo htmlspecialchars($row['registration_fee']); ?></td>
            <td><?php echo htmlspecialchars($row['registration_closing_date_time']); ?></td>
            <td><?php echo htmlspecialchars($row['participation_type']); ?></td>
            <td><?php echo htmlspecialchars($row['min_group_size']); ?></td>
            <td><?php echo htmlspecialchars($row['max_group_size']); ?></td>
            <td>
                <a href="update_event.php?event_id=<?php echo $row['event_id']; ?>" class="btn btn-update">Update</a>
                <a href="delete_event.php?event_id=<?php echo $row['event_id']; ?>" class="btn btn-delete" onclick="return confirm('Are you sure you want to delete this event?')">Delete</a>
                <a href="view_registered_students.php?event_id=<?php echo $row['event_id']; ?>" class="btn btn-view">View Students</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
    <a href="admin_dashboard.php" class="back-button">Back</a>
</div>

<?php
$conn->close();
?>

</body>
</html>
