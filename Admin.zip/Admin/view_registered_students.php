<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "event_managements";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("<p class='error'>Connection failed: " . $conn->connect_error . "</p>");
}

// Ensure event_id is passed in the URL
if (!isset($_GET['event_id'])) {
    die("<p class='error'>No event selected. Please go back and select an event.</p>");
}

$event_id = $_GET['event_id'];

// Fetch event details
$stmt = $conn->prepare("SELECT event_name, start_date_time, location FROM events WHERE event_id = ?");
$stmt->bind_param("i", $event_id);
$stmt->execute();
$event_result = $stmt->get_result();
$event = $event_result->fetch_assoc();
$event_name = $event['event_name'];
$event_date = $event['start_date_time'];
$event_location = $event['location'];

// Fetch registrations for the event
$stmt = $conn->prepare("SELECT r.registration_id, r.name, r.usn, r.semester, r.email, r.registration_time, r.participation_type, r.utr_number 
                        FROM registrations r WHERE r.event_id = ?");
$stmt->bind_param("i", $event_id);
$stmt->execute();
$registrations_result = $stmt->get_result();

// Handle confirm action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_registration_id'])) {
    $registration_id = $_POST['confirm_registration_id'];
    
    // Get user details
    $sql = "SELECT name, email FROM registrations WHERE registration_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $registration_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    
    // Send confirmation email
    if ($user) {
        $to = $user['email'];
        $subject = "Event Registration Confirmation: $event_name";
        $message = "Dear " . $user['name'] . ",\n\nYour registration for the event '$event_name' has been confirmed.\nEvent Details:\nDate: $event_date\nLocation: $event_location\n\nThank you for registering!";
        $headers = "From: no-reply@event.com";

        // Send email
        if (mail($to, $subject, $message, $headers)) {
            echo "<p class='success'>Confirmation email sent to " . htmlspecialchars($user['name']) . ".</p>";
            
            // Update the registration status (optional, you can add a column for confirmation status)
            $update_sql = "UPDATE registrations SET status = 'Confirmed' WHERE registration_id = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("i", $registration_id);
            $update_stmt->execute();
        } else {
            echo "<p class='error'>Failed to send the confirmation email.</p>";
        }
    }
}

// Handle rejection action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reject_registration_id'])) {
    $registration_id = $_POST['reject_registration_id'];
    $rejection_reason = $_POST['rejection_reason'];

    // Get user details
    $sql = "SELECT name, email FROM registrations WHERE registration_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $registration_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    // Send rejection email
    if ($user) {
        $to = $user['email'];
        $subject = "Event Registration Rejected: $event_name";
        $message = "Dear " . $user['name'] . ",\n\nYour registration for the event '$event_name' has been rejected.\nReason: $rejection_reason\n\nPlease contact us to this below number\n\n 8088664012.\n\nThank you.";
        $headers = "From: no-reply@event.com";

        // Send email
        if (mail($to, $subject, $message, $headers)) {
            echo "<p class='success'>Rejection email sent to " . htmlspecialchars($user['name']) . ".</p>";

            // Update the registration status to "Rejected" to allow re-registration
            $update_sql = "UPDATE registrations SET status = 'Rejected' WHERE registration_id = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("i", $registration_id);
            $update_stmt->execute();
        } else {
            echo "<p class='error'>Failed to send the rejection email.</p>";
        }
    }
}

// Handle send feedback form action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_feedback'])) {
    $sent_emails = 0;

    // Loop through the registrations and send feedback form link
    while ($row = $registrations_result->fetch_assoc()) {
        $feedback_form_link = "https://docs.google.com/forms/d/e/1FAIpQLSdeJ8qEDz0Bj3nGk-hW-8EgLJV8HmA--NDpI7VsVK0RvK-1cA/viewform?usp=pp_url"
            . "&entry.1000000001=" . urlencode($row['name']) // Student name
            . "&entry.1000000002=" . urlencode($row['usn'])  // Student USN
            . "&entry.1000000003=" . urlencode($event_id);   // Event ID

        $to = $row['email'];
        $subject = "Feedback Form for Event: " . $event_name;
        $message = "Dear " . htmlspecialchars($row['name']) . ",\n\n"
                 . "Thank you for participating in our event: " . htmlspecialchars($event_name) . ".\n"
                 . "We value your feedback! Please take a moment to complete the feedback form using the link below:\n\n"
                 . $feedback_form_link . "\n\n"
                 . "Best regards,\nEvent Management Team";
        $headers = "From: admin@eventmanagement.com";

        if (mail($to, $subject, $message, $headers)) {
            $sent_emails++;
        }
    }

    echo "<script>alert('Feedback form sent to $sent_emails students.');</script>";
    $registrations_result->data_seek(0); // Reset the result pointer for reuse
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registered Students for <?= htmlspecialchars($event_name) ?></title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; background-color: #f4f4f9; }
        .container { width: 90%; margin: 0 auto; padding: 20px; }
        h1 { font-size: 28px; color: #333; text-align: center; }
        .event-info p { font-size: 18px; margin: 5px 0; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        table, th, td { border: 1px solid #ddd; }
        th, td { padding: 10px; text-align: left; }
        th { background-color: #007bff; color: white; }
        .action-btn { background-color: #28a745; color: white; padding: 5px 10px; border: none; border-radius: 4px; cursor: pointer; }
        .action-btn:hover { background-color: #218838; }
        button[name="send_feedback"] { padding: 10px 15px; background-color: #007BFF; color: white; border: none; border-radius: 5px; cursor: pointer; }
        button[name="send_feedback"]:hover { background-color: #0056b3; }
        .error { background-color: #f8d7da; color: #721c24; padding: 10px; border-radius: 4px; margin-bottom: 20px; }
        .success { background-color: #d4edda; color: #155724; padding: 10px; border-radius: 4px; margin-bottom: 20px; }
    </style>
</head>
<body>

<div class="container">
    <h1>Registered Students for <?= htmlspecialchars($event_name) ?></h1>
    
    <div class="event-info">
        <p><strong>Date:</strong> <?= htmlspecialchars($event_date) ?></p>
        <p><strong>Location:</strong> <?= htmlspecialchars($event_location) ?></p>
    </div>

    <?php if ($registrations_result->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>USN</th>
                    <th>Semester</th>
                    <th>Email</th>
                    <th>Registration Time</th>
                    <th>Participation Type</th>
                    <th>Group Members</th>
                    <th>UTR Number</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $registrations_result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['name']) ?></td>
                        <td><?= htmlspecialchars($row['usn']) ?></td>
                        <td><?= htmlspecialchars($row['semester']) ?></td>
                        <td><?= htmlspecialchars($row['email']) ?></td>
                        <td><?= htmlspecialchars($row['registration_time']) ?></td>
                        <td><?= htmlspecialchars($row['participation_type']) ?></td>
                        <td>
                            <?php
                            if ($row['participation_type'] == 'Group') {
                                $group_sql = "SELECT member_name FROM group_members WHERE registration_id = ?";
                                $group_stmt = $conn->prepare($group_sql);
                                $group_stmt->bind_param("i", $row['registration_id']);
                                $group_stmt->execute();
                                $group_result = $group_stmt->get_result();

                                while ($group_row = $group_result->fetch_assoc()) {
                                    echo htmlspecialchars($group_row['member_name']) . "<br>";
                                }
                            }
                            ?>
                        </td>
                        <td>
                            <?php if ($row['utr_number']): ?>
                                <?= htmlspecialchars($row['utr_number']) ?>
                            <?php else: ?>
                                No UTR number provided
                            <?php endif; ?>
                        </td>
                        <td>
                            <form method="post" style="display: inline;">
                                <input type="hidden" name="confirm_registration_id" value="<?= $row['registration_id'] ?>">
                                <button type="submit" class="action-btn">Confirm</button>
                            </form>
                            <form method="post" style="display: inline;">
                                <input type="hidden" name="reject_registration_id" value="<?= $row['registration_id'] ?>">
                                <input type="text" name="rejection_reason" placeholder="Reason for rejection" required>
                                <button type="submit" class="action-btn" style="background-color: #dc3545;">Reject</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="error">No registrations for this event yet.</p>
    <?php endif; ?>

    <form method="post">
        <button type="submit" name="send_feedback">Send Feedback Form to All Registered Students</button>
        <a href="admin_dashboard.php"><button class="action-btn">Back to Dashboard</button></a>
    </form>

</div>

</body>
</html>
