<!DOCTYPE html>
<html>
<head>
    <title>Login Form</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            text-align: center;
            margin: 0;
            padding: 0;
            background: url('images/backgrounds.jfif') no-repeat center center fixed;
            background-size: cover;
            color: #fff;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        h1 {
            font-size: 36px;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
        }

        p {
            font-size: 18px;
            margin-bottom: 30px;
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.6);
        }

        .login-buttons {
            margin-top: 20px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            justify-content: center;
        }

        button {
            background: rgba(255, 255, 255, 0.8);
            color: #2575fc;
            border: none;
            padding: 12px 25px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 30px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }

        button:hover {
            background: #2575fc;
            color: #fff;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
            transform: translateY(-2px);
        }

        button:active {
            transform: translateY(2px);
            box-shadow: 0 3px 5px rgba(0, 0, 0, 0.2);
        }

        .back-button {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h1>Welcome to the Event Management System</h1>
    <p>Please select your login option:</p>

    <div class="login-buttons">
        <!-- User Login Button -->
        <button onclick="location.href='user_login.php'">User Login</button>

        <!-- Admin Login Button -->
        <button onclick="location.href='admin_login.php'">Admin Login</button>
    </div>

    <!-- Back to Home Button -->
    <div class="back-button">
        <button onclick="location.href='index.php'">Back to Home</button>
    </div>
</body>
</html>
