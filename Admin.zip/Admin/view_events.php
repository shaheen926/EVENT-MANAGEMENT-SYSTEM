<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

// Database connection
$conn = new mysqli('localhost', 'root', '', 'event_managements');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get list of events
$sql = "SELECT * FROM events";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Events</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 0;
        }

        h1 {
            text-align: center;
            padding: 20px;
            background-color: #4CAF50;
            color: white;
            margin-bottom: 20px;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .event-header {
            font-size: 24px;
            font-weight: bold;
            color: #4CAF50;
            margin-bottom: 10px;
        }

        .event-details {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            background-color: #fafafa;
        }

        .event-details p {
            margin: 8px 0;
        }

        .event-details strong {
            color: #4CAF50;
        }

        .image-container {
            margin: 15px 0;
            text-align: center;
        }

        .image-container img {
            width: 200px;
            height: auto;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .registered-students {
            margin-top: 20px;
            padding: 15px;
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 8px;
        }

        .registered-students h3 {
            color: #4CAF50;
        }

        .registered-students p {
            font-size: 16px;
            color: #555;
        }

        .footer {
            text-align: center;
            padding: 10px;
            background-color: #333;
            color: white;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

        hr {
            border: 1px solid #ddd;
        }
    </style>
</head>
<body>

    <h1>Event List</h1>
    <div class="container">

    <?php while ($row = $result->fetch_assoc()): ?>
        <div class="event-header">
            <?php echo $row['event_name']; ?> (<?php echo $row['category']; ?>)
        </div>

        <div class="event-details">
            <p><strong>Coordinator:</strong> <?php echo $row['staff_coordinator']; ?></p>
            <p><strong>Location:</strong> <?php echo $row['location']; ?></p>
            <p><strong>Start Time:</strong> <?php echo $row['start_date_time']; ?></p>
            <p><strong>End Time:</strong> <?php echo $row['end_date_time']; ?></p>
            <p><strong>Closing Time:</strong> <?php echo $row['registration_closing_date_time']; ?></p>
            <p><strong>About Event:</strong> <?php echo $row['description']; ?></p>
        </div>

        <div class="image-container">
            <p><strong>Event Image:</strong></p>
            <img src="<?php echo $row['image']; ?>" alt="Event Image">
        </div>

        <!-- View registered students for this event -->
        <div class="registered-students">
            <h3>Registered Students:</h3>
            <?php
            $event_id = $row['event_id'];
            $sql_registrations = "SELECT * FROM registrations WHERE event_id = '$event_id'";
            $result_registrations = $conn->query($sql_registrations);

            while ($registration = $result_registrations->fetch_assoc()) {
                echo "<p>" . $registration['name'] . " - " . $registration['email'] . "</p>";
            }
            ?>
        </div>

        <hr>
    <?php endwhile; ?>

    </div>

    <div class="footer">
        &copy; 2025 Event Management System
    </div>

    <?php $conn->close(); ?>
</body>
</html>

