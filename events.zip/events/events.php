<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Event_managements";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch events by category using prepared statements for security
$category = isset($_GET['category']) ? $_GET['category'] : 'Technical';
$stmt = $conn->prepare("SELECT * FROM events WHERE category = ?");
$stmt->bind_param("s", $category);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Events</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: rgb(240, 240, 240);
        }

        .header {
            background-color: #003366;
            color: white;
            padding: 15px 30px;
            text-align: center;
        }

        .header h1 {
            margin: 0;
            font-size: 30px;
            text-transform: uppercase;
        }

        .category-nav {
            display: flex;
            justify-content: center;
            background-color: #ffcc00;
            padding: 10px 0;
        }

        .category-nav a {
            text-decoration: none;
            color: #003366;
            margin: 0 15px;
            font-size: 18px;
            font-weight: bold;
            transition: color 0.3s;
        }

        .category-nav a:hover {
            color: white;
        }

        .events-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            padding: 20px;
        }

        .event-card {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            margin: 15px;
            width: 300px;
            overflow: hidden;
            transition: transform 0.3s;
        }

        .event-card:hover {
            transform: translateY(-5px);
        }

        .event-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }

        .event-details {
            padding: 15px;
        }

        .event-details h3 {
            font-size: 22px;
            color: #003366;
            margin-bottom: 10px;
        }

        .event-details p {
            margin: 5px 0;
            color: #555;
            font-size: 16px;
        }

        .event-details .btn {
            display: inline-block;
            margin-top: 10px;
            padding: 10px 20px;
            background-color: #003366;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            text-align: center;
        }

        .event-details .btn:hover {
            background-color: #ffcc00;
            color: #003366;
        }

        .no-events {
            text-align: center;
            font-size: 18px;
            color: #333;
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Events</h1>
    </div>

    <!-- Category Navigation -->
    <div class="category-nav">
        <a href="events.php?category=Technical">Technical Events</a>
        <a href="events.php?category=Cultural">Cultural Events</a>
        <a href="events.php?category=Sports">Sports Events</a>
    </div>

    <!-- Events Display -->
    <div class="events-container">
        <?php
        if ($result->num_rows > 0) {
            $currentDateTime = date("Y-m-d H:i:s"); // Current date and time
            while ($row = $result->fetch_assoc()) {
                $registrationClosingDate = $row['registration_closing_date_time'];
                $registrationLimit = $row['registration_limit']; // Get registration limit
                $participationType = $row['participation_type']; // Get participation type
                $department = $row['department']; // Get department
                $registeredCount = 0; // Assuming a query to count registered participants
                
                // Fetch the number of registered users for this event
                $countStmt = $conn->prepare("SELECT COUNT(*) FROM registrations WHERE event_id = ?");
                $countStmt->bind_param("i", $row['event_id']);
                $countStmt->execute();
                $countResult = $countStmt->get_result();
                $countRow = $countResult->fetch_assoc();
                $registeredCount = $countRow['COUNT(*)'];
                
                echo "
                <div class='event-card'>
                    <img src='" . htmlspecialchars($row['image'], ENT_QUOTES, 'UTF-8') . "' alt='" . htmlspecialchars($row['event_name'], ENT_QUOTES, 'UTF-8') . "'>
                    <div class='event-details'>
                        <h3>" . htmlspecialchars($row['event_name'], ENT_QUOTES, 'UTF-8') . "</h3>
                        <p><b>Department:</b> " . htmlspecialchars($department, ENT_QUOTES, 'UTF-8') . "</p>
                        <p><b>Participation Type:</b> " . htmlspecialchars($participationType, ENT_QUOTES, 'UTF-8') . "</p>
                        <p>" . htmlspecialchars($row['description'], ENT_QUOTES, 'UTF-8') . "</p>
                        <p><b>Start:</b> " . htmlspecialchars($row['start_date_time'], ENT_QUOTES, 'UTF-8') . "</p>
                        <p><b>End:</b> " . htmlspecialchars($row['end_date_time'], ENT_QUOTES, 'UTF-8') . "</p>
                        <p><b>Location:</b> " . htmlspecialchars($row['location'], ENT_QUOTES, 'UTF-8') . "</p>
                        <p><b>Registration Closes:</b> " . htmlspecialchars($registrationClosingDate, ENT_QUOTES, 'UTF-8') . "</p>
                        <p><b>Registration Limit:</b> " . htmlspecialchars($registrationLimit, ENT_QUOTES, 'UTF-8') . "</p>
                        <p><b>Registered:</b> " . $registeredCount . " out of " . htmlspecialchars($registrationLimit, ENT_QUOTES, 'UTF-8') . " participants</p>";
                        
                // Display the Register button if registration is still open and limit hasn't been reached
                if ($currentDateTime < $registrationClosingDate && $registeredCount < $registrationLimit) {
                    echo "<a class='btn' href='register.php?event_id=" . $row['event_id'] . "'>Register</a>";
                } else {
                    echo "<p style='color: red; font-weight: bold;'>Registration Closed or Limit Reached</p>";
                }

                echo "
                    </div>
                </div>
                ";
            }
        } else {
            echo "<div class='no-events'>No events available for this category.</div>";
        }
        ?>
    </div>
</body>
</html>

<?php
// Close the prepared statement and connection
$stmt->close();
$conn->close();
?>
