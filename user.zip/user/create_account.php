<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "event_managements");

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$email = $_GET['email'];  // Get email from the URL
$message = ""; // To store success or error messages

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Server-side validation for username and password
    if (!preg_match('/^[a-zA-Z]{1,8}$/', $username)) {
        $message = "Username must be a maximum of 8 characters and contain only letters.";
    } elseif (!preg_match('/^(?=.*[a-zA-Z])(?=.*\d)(?=.*[@#*!])[a-zA-Z\d@#*!]{6,10}$/', $password))
    {
        $message = "Password must be exactly 6 characters, include letters, digits, and at least one special character.";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert username and password into the database
        $query = "UPDATE users SET username = ?, password = ? WHERE email = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sss", $username, $hashed_password, $email);

        if ($stmt->execute()) {
            $message = "Account created successfully! You can now <a href='login.php'>login</a>.";
        } else {
            $message = "Error creating account. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account</title>
    <style>
        /* General styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f4f8;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        /* Form container */
        .container {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            width: 100%;
            text-align: center;
        }

        /* Heading */
        h2 {
            margin-bottom: 20px;
            color: #007bff;
        }

        /* Form styles */
        label {
            font-size: 14px;
            color: #555;
            text-align: left;
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
            outline: none;
            transition: border-color 0.3s;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            border-color: #007bff;
        }

        button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 14px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #0056b3;
        }

        /* Message styles */
        p {
            font-size: 14px;
            color: #333;
        }

        p a {
            color: #007bff;
            text-decoration: none;
            font-weight: bold;
        }

        p a:hover {
            text-decoration: underline;
        }
    </style>
    <script>
        // Client-side validation
        function validateForm() {
            const usernameRegex = /^[a-zA-Z]{1,8}$/; // Username must be a maximum of 8 letters
            const passwordRegex = !preg_match('/^(?=.*[a-zA-Z])(?=.*\d)(?=.*[@#*!])[a-zA-Z\d@#*!]{6,10}$/; // Password must be 6 characters, include letters, digits, and a special character

            const username = document.forms["accountForm"]["username"].value;
            const password = document.forms["accountForm"]["password"].value;

            if (!usernameRegex.test(username)) {
                alert("Username must be a maximum of 8 characters and contain only letters.");
                return false;
            }
            if (!passwordRegex.test(password)) {
                alert("Password must be exactly 10 characters, include letters, digits, and at least one special character.");
                return false;
            }
            return true;
        }
    </script>
</head>
<body>
    <div class="container">
        <h2>Create Account</h2>
        <?php if ($message): ?>
            <p><?php echo $message; ?></p>
        <?php endif; ?>
        <form method="POST" name="accountForm" onsubmit="return validateForm()">
            <label for="username">Create a Username:</label>
            <input type="text" name="username" required>

            <label for="password">Create a Password:</label>
            <input type="password" name="password" required>

            <button type="submit">Create Account</button>
        </form> <br> <br>
        <a href="index.php">
            <button type="button" class="back-button">Go Back</button>
        </a>
    </div>
</body>
</html>
