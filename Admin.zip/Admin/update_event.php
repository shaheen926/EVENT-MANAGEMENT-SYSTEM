<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

$conn = new mysqli('localhost', 'root', '', 'event_managements');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle Event Data Fetching or Updating
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $event_id = $_GET['event_id'];
    $sql = "SELECT * FROM events WHERE event_id = $event_id";
    $result = $conn->query($sql);
    $event = $result->fetch_assoc();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $event_id = $_POST['event_id'];
    $department = $_POST['department'];
    $category = $_POST['category'];
    $event_name = $_POST['event_name'];
    $staff_coordinator = $_POST['staff_coordinator'];
    $start_date_time = $_POST['start_date_time'];
    $end_date_time = $_POST['end_date_time'];
    $location = $_POST['location'];
    $registration_closing_date_time = $_POST['registration_closing_date_time'];
    $registration_limit = $_POST['registration_limit'];
    $participation_type = $_POST['participation_type'];
    $min_group_size = isset($_POST['min_group_size']) ? $_POST['min_group_size'] : 1;
    $max_group_size = isset($_POST['max_group_size']) ? $_POST['max_group_size'] : 1;
    $description = $_POST['description'];
    $registration_fee = $_POST['registration_fee'];

    // Handle the image upload for event image
    $image = $event['image'];
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $image_name = $_FILES['image']['name'];
        $image_tmp_name = $_FILES['image']['tmp_name'];
        $image_extension = pathinfo($image_name, PATHINFO_EXTENSION);
        $allowed_extensions = array("jpg", "jpeg", "png", "gif", "jfif");

        if (in_array(strtolower($image_extension), $allowed_extensions)) {
            $upload_path = "uploads/" . time() . "_" . $image_name;
            if (!is_dir('uploads')) {
                mkdir('uploads', 0777, true);
            }
            if (move_uploaded_file($image_tmp_name, $upload_path)) {
                $image = $upload_path;
            } else {
                echo "Error uploading image.";
            }
        } else {
            echo "Invalid image file type.";
        }
    }

    // Handle the image upload for payment QR code
    $payment_qr_code = $event['payment_qr_code'];
    if (isset($_FILES['payment_qr_code']) && $_FILES['payment_qr_code']['error'] == 0) {
        $qr_name = $_FILES['payment_qr_code']['name'];
        $qr_tmp_name = $_FILES['payment_qr_code']['tmp_name'];
        $qr_extension = pathinfo($qr_name, PATHINFO_EXTENSION);
        $allowed_qr_extensions = array("jpg", "jpeg", "png", "gif", "jfif");

        if (in_array(strtolower($qr_extension), $allowed_qr_extensions)) {
            $qr_upload_path = "uploads/qr_codes/" . time() . "_" . $qr_name;
            if (!is_dir('uploads/qr_codes')) {
                mkdir('uploads/qr_codes', 0777, true);
            }
            if (move_uploaded_file($qr_tmp_name, $qr_upload_path)) {
                $payment_qr_code = $qr_upload_path;
            } else {
                echo "Error uploading QR code.";
            }
        } else {
            echo "Invalid QR code file type.";
        }
    }

    // Update event data in the database
    $sql = "UPDATE events 
            SET department = '$department', category = '$category', event_name = '$event_name', description = '$description', 
                location = '$location', image = '$image', staff_coordinator = '$staff_coordinator', 
                start_date_time = '$start_date_time', end_date_time = '$end_date_time', 
                registration_closing_date_time = '$registration_closing_date_time', registration_limit = $registration_limit, 
                participation_type = '$participation_type', min_group_size = $min_group_size, max_group_size = $max_group_size, 
                registration_fee = $registration_fee, payment_qr_code = '$payment_qr_code' 
            WHERE event_id = $event_id";

    if ($conn->query($sql) === TRUE) {
        echo "Event updated successfully!";
        header('Location: manage_events.php');  // Redirect after success
        exit;
    } else {
        echo "Error updating event: " . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Event</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fc;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 50%;
            margin: 50px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        label {
            display: block;
            margin: 10px 0 5px;
            font-size: 14px;
            font-weight: bold;
            color: #555;
        }

        input[type="text"],
        input[type="file"],
        input[type="datetime-local"],
        select,
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
            color: #333;
        }

        textarea {
            resize: vertical;
        }

        button[type="submit"] {
            width: 100%;
            padding: 12px;
            background-color: #5cb85c;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button[type="submit"]:hover {
            background-color: #4cae4c;
        }

        .back-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            text-decoration: none;
            background-color: #f0ad4e;
            color: white;
            font-weight: bold;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        .back-button:hover {
            background-color: #ec971f;
        }

        .form-group {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Update Event</h1>
        <form method="POST" action="update_event.php" enctype="multipart/form-data">
            <input type="hidden" name="event_id" value="<?php echo $event['event_id']; ?>">

            <!-- Department -->
            <label>Department:</label>
            <select name="department" required>
                <option value="CSE" <?php if ($event['department'] == 'CSE') echo 'selected'; ?>>Computer Science & Engineering</option>
                <option value="ISE" <?php if ($event['department'] == 'ISE') echo 'selected'; ?>>Information Science & Engineering</option>
                <!-- Add other departments -->
            </select>

            <!-- Event Type -->
            <label>Event Type:</label>
            <select name="category" required>
                <option value="Technical" <?php if ($event['category'] == 'Technical') echo 'selected'; ?>>Technical</option>
                <option value="Sports" <?php if ($event['category'] == 'Sports') echo 'selected'; ?>>Sports</option>
                <option value="Cultural" <?php if ($event['category'] == 'Cultural') echo 'selected'; ?>>Cultural</option>
            </select>

            <!-- Event Name -->
            <label>Event Name:</label>
            <input type="text" name="event_name" value="<?php echo $event['event_name']; ?>" required>

            <!-- Staff Coordinator -->
            <label>Staff Coordinator:</label>
            <input type="text" name="staff_coordinator" value="<?php echo $event['staff_coordinator']; ?>" required>

            <!-- Start Date/Time -->
            <label>Start Date & Time:</label>
            <input type="datetime-local" name="start_date_time" value="<?php echo $event['start_date_time']; ?>" required>

            <!-- End Date/Time -->
            <label>End Date & Time:</label>
            <input type="datetime-local" name="end_date_time" value="<?php echo $event['end_date_time']; ?>" required>

            <!-- Location -->
            <label>Location:</label>
            <input type="text" name="location" value="<?php echo $event['location']; ?>" required>

            <!-- Registration Closing Date/Time -->
            <label>Registration Closing Date & Time:</label>
            <input type="datetime-local" name="registration_closing_date_time" value="<?php echo $event['registration_closing_date_time']; ?>" required>

            <!-- Registration Limit -->
            <label>Registration Limit:</label>
            <input type="number" name="registration_limit" value="<?php echo $event['registration_limit']; ?>" required>

            <!-- Participation Type -->
            <label>Participation Type:</label>
            <select name="participation_type" required>
                <option value="Individual" <?php if ($event['participation_type'] == 'Individual') echo 'selected'; ?>>Individual</option>
                <option value="Group" <?php if ($event['participation_type'] == 'Group') echo 'selected'; ?>>Group</option>
            </select>

            <!-- Minimum Group Size -->
            <label>Minimum Group Size:</label>
            <input type="number" name="min_group_size" value="<?php echo $event['min_group_size']; ?>" required>

            <!-- Maximum Group Size -->
            <label>Maximum Group Size:</label>
            <input type="number" name="max_group_size" value="<?php echo $event['max_group_size']; ?>" required>

            <!-- Event Description -->
            <label>Event Description:</label>
            <textarea name="description" rows="4" required><?php echo $event['description']; ?></textarea>

            <!-- Registration Fee -->
            <label>Registration Fee:</label>
            <input type="number" name="registration_fee" value="<?php echo $event['registration_fee']; ?>" required>

            <!-- Event Image -->
            <label>Event Image:</label>
            <input type="file" name="image">

            <!-- Payment QR Code -->
            <label>Payment QR Code:</label>
            <input type="file" name="payment_qr_code">

            <button type="submit">Update Event</button>
        </form>

        <a href="manage_events.php" class="back-button">Back to Manage Events</a>
    </div>
</body>
</html>
