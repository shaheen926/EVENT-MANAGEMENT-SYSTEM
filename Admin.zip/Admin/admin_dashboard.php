<?php
session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('images/backgrounds.jfif'); /* Update with your preferred background image path */
            background-size: cover;
            background-position: center;
            color: white;
        }

        h1 {
            text-align: center;
            font-size: 3em;
            margin-top: 100px;
            text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.5);
        }

        .menu {
            display: flex;
            justify-content: center;
            margin-top: 50px;
        }

        .menu a {
            display: inline-block;
            margin: 10px;
            padding: 20px 40px;
            background-color: rgba(0, 123, 255, 0.8); /* Semi-transparent background */
            color: white;
            text-decoration: none;
            font-size: 1.2em;
            border-radius: 8px;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
        }

        .menu a:hover {
            background-color: rgba(0, 56, 115, 0.8); /* Darker shade on hover */
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.4);
        }

        .menu a:active {
            transform: translateY(2px); /* Button presses down effect */
        }

        /* Add a semi-transparent overlay for the background */
        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.4);
            z-index: -1;
        }

    </style>
</head>
<body>
    <div class="overlay"></div>
    <h1>Welcome, Admin</h1>
    <div class="menu">
        <a href="create_event.php">Create Event</a>
        <a href="view_events.php">View Events</a>
        <a href="manage_events.php">Manage Events</a>
        <a href="view_feedback.php">View Feedbacks</a> <!-- New View Feedbacks Button -->
        <a href="index.php">Logout</a>
    </div>
</body>
</html>
